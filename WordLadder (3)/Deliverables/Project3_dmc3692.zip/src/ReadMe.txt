{\rtf1\ansi\ansicpg1252\cocoartf1561\cocoasubrtf200
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 wordLadder\
Made By: Dylan Cauwels \
EID: dmc3692\
\
Project Structure:: \
The WordLadder functions are contained within 3 classes- Main, Graph, and Vertex. Main is the algorithms for manipulating the two data structures. Graph is the large structure holding all the vertices inside a hash map. All searching and construction happens in the main class but references both the graph and vertex classes consistently.\
\
Assumptions::\
There will be no words not 5 letters \
All words will be in the dictionary \
No Team Plan or Testing Plan required (from the TA\'92s)\
\
\
Corner Cases::\
\ul Depth searches without Ladders\ulnone \
this is important because unending recursive calls with consistently lead to stack overflow. To prevent this the DFS method is heavily optimized. A hash table marks what Vertices have been visited to prevent repeated Vertex investigations. A small method in the vertex class organizes the adjacency list in the Vertex based on how many letters they have in common with the end case, so these words get searched first. As a final precaution, a global counter is implemented into the recursive method so if the calls exceed 3,000 the method is automatically stopped and a \'91no solution\'92 is assumed.  \
\ul Valid 0-step Ladders **accidentally did it even though the pdf says otherwise\
\ulnone When the start and endpoints are a valid ladder the wordLadder method doesn\'92t return null like it would if they weren\'92t a valid Ladder. The actual differentiation between a two word ArrayList and a valid ladder ArrayList is done by the printLadder function as it is the only one that actually changes. It calls a help oneCharDifference method that tells it whether to print \'93no valid word ladder\'94 or \'930-rung word ladder between\'94.\
\ul Breadth searches without Ladders\ulnone \
These are fairly easy because Breadth doesn\'92t use up the stack like the Depth does. For this I simply have a condition at the end of the method that adds the start and end Strings to the ArrayList if the method is going to return null (because no ladder is found). This prevents any Null pointer exceptions later on as well. \
\
Other::\
Initialize method is not required- all required variables are initialized and used within their respective Methods. Sort method is implemented in DFS to improve efficiency considerably. HashMaps are also used for both BFS and DFS to most efficiently mark visited Vertices. All class variables are private, but can be reached through given methods. Any additional questions can be sent to dm.cauwels@utexas.edu or by text through (817)-948-4382.}