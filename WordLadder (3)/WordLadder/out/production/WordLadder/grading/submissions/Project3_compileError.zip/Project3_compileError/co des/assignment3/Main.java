package i.am.compie.error;
import java.util.*;
import java.io.*;

public class Main {
	
	public static void main(String[] args) throws Exception {
        System.out.println("compile error sample submission");
	}
	
	public static void initialize() {}
	
	public static ArrayList<String> parse(Scanner keyboard) { return null; }
	
	public static ArrayList<String> getWordLadderDFS(String start, String end) {
		return null;
	}
	
    public static ArrayList<String> getWordLadderBFS(String start, String end) {
		return null;
	}
	
	public static void printLadder(ArrayList<String> ladder) {
	}
}
