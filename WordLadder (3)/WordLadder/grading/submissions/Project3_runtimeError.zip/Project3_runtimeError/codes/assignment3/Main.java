package assignment3;
import java.util.*;
import java.io.*;

public class Main {
    static String foo = "foo";
	public static void main(String[] args) throws Exception {
        if("foo".equals(foo)) throw new RuntimeException("Sample submission with runtime error.");
	}
	public static void initialize() {}
	public static ArrayList<String> parse(Scanner keyboard) {
        if("foo".equals(foo)) throw new RuntimeException("Sample submission with runtime error.");
		return null;
	}
	public static ArrayList<String> getWordLadderDFS(String start, String end) {
        if("foo".equals(foo)) throw new RuntimeException("Sample submission with runtime error.");
		return null;
	}
    public static ArrayList<String> getWordLadderBFS(String start, String end) {
        if("foo".equals(foo)) throw new RuntimeException("Sample submission with runtime error.");
		return null;
	}
	public static void printLadder(ArrayList<String> ladder) {}
	public static Set<String>  makeDictionary () {
		Set<String> words = new HashSet<String>();
		Scanner infile = null;
		try {
			infile = new Scanner (new File("five_letter_words.txt"));
		} catch (FileNotFoundException e) {
			System.out.println("Dictionary File not Found!");
			e.printStackTrace();
			System.exit(1);
		}
		while (infile.hasNext()) {
			words.add(infile.next().toUpperCase());
		}
		return words;
	}
}
